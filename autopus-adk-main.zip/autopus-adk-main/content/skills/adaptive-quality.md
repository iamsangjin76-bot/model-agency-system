---
name: adaptive-quality
description: Per-task model selection based on complexity in Balanced quality mode
triggers:
  - adaptive quality
  - 적응형 품질
  - complexity
  - 복잡도
category: agentic
level1_metadata: "adaptive quality, complexity assessment, model selection, cost optimization, Balanced mode"
---

# Adaptive Quality Skill

## Overview

Adaptive Quality is a sub-extension of Quality Mode. In **Balanced mode only**, task complexity determines the model used for each `Agent()` call. This allows high-complexity tasks to receive full opus capability while routine tasks use lighter, faster models — reducing cost without sacrificing quality where it matters.

## Relationship to Quality Mode

| Mode | Behavior |
|------|----------|
| **Ultra** | ALL tasks use opus. Complexity is IGNORED. |
| **Balanced** | Complexity determines model. Adaptive Quality applies. |
| **Solo** | No Agent() calls. Not applicable. |

Adaptive Quality is **not** a replacement for Quality Mode — it is a refinement that operates exclusively within Balanced mode.

## Complexity Assessment Criteria

The planner assesses each task before spawning an agent. The assessment considers:

| Factor | Weight |
|--------|--------|
| `file_count` | Number of files to be modified |
| `estimated_lines` | Expected lines of new/changed code |
| `requirement_count` | Number of distinct requirements |
| `dependency_count` | Number of packages/modules involved |

### Complexity Levels

| Level | Criteria |
|-------|----------|
| **HIGH** | 3+ files OR 200+ expected lines OR complex logic/architecture decisions |
| **MEDIUM** | 1–2 files, 50–200 lines, moderate logic |
| **LOW** | 1 file, under 50 lines, simple or mechanical changes |

When criteria overlap (e.g., 1 file but 250 lines), use the highest matching level.

## Model Mapping Table

| Complexity | Model (Balanced) | Model (Ultra) |
|-----------|-----------------|---------------|
| HIGH | opus | opus |
| MEDIUM | sonnet (default) | opus |
| LOW | haiku | opus |

## Agent() Call Pattern

### HIGH complexity

```python
Agent(
    subagent_type="executor",
    model="opus",
    prompt=task_prompt
)
```

### MEDIUM complexity

```python
# No model param — uses pipeline default (sonnet)
Agent(
    subagent_type="executor",
    prompt=task_prompt
)
```

### LOW complexity

```python
Agent(
    subagent_type="executor",
    model="haiku",
    prompt=task_prompt
)
```

## Configuration Override (`autopus.yaml`)

Override the default model mapping per complexity level:

```yaml
quality:
  presets:
    balanced:
      adaptive:
        high: opus
        medium: sonnet
        low: haiku
```

To disable adaptive quality and use a fixed model in Balanced mode:

```yaml
quality:
  presets:
    balanced:
      adaptive: false
      model: sonnet
```

## Cost Estimation

### Formula

```
cost = Σ(task_tokens × model_price_per_token)
```

Where `model_price_per_token` is looked up from the pricing table in `pkg/cost/estimator.go`.

### Estimated Savings

| Scenario | Savings vs All-Opus |
|----------|---------------------|
| Typical project (mixed complexity) | 20–40% |
| Mostly LOW tasks (refactoring, docs) | up to 60% |
| Mostly HIGH tasks (new features) | < 5% |

**Reference**: `pkg/cost/estimator.go` for current pricing tables and token estimation logic.

## Planner Integration

The planner executes complexity assessment during Phase 1 and annotates each task:

```
Task T1: Add user authentication
  → file_count: 4, estimated_lines: 280
  → Complexity: HIGH → model: opus

Task T2: Update error message string
  → file_count: 1, estimated_lines: 3
  → Complexity: LOW → model: haiku
```

The complexity annotation is included in the execution plan and passed to the orchestrator before Agent() calls are made.
